#include <iostream>
#include <locale>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");

    int n1, n2;

    cout << "Digite o primeiro n�mero: ";
    cin >> n1;

    cout << "Digite o segundo n�mero: ";
    cin >> n2;

    if (n1 > n2){
        cout << "\nO maior n�mero �: " << n1 << endl;
    }
    else{
        cout << "O maior n�mero �: " << n2 << endl;
    }
    return 0;
}
